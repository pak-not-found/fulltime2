import { Button } from "@/components/ui/button";
import { ArrowRight, Sparkles, TrendingUp, Target, Zap } from "lucide-react";
import { useTypingEffect } from "@/hooks/useTypingEffect";

const Hero = () => {
  const typingWords = [
    "Digital Marketing",
    "Facebook Ads",
    "YouTube Campaigns",
    "Google Ads",
    "Social Media Growth",
    "Brand Strategy"
  ];
  
  const typedText = useTypingEffect(typingWords, 120, 80, 1500);

  const scrollToContact = () => {
    const element = document.getElementById("contact");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden">
      {/* Animated Background Effects */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-background to-secondary/5"></div>
      
      {/* Animated Gradient Orbs */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-1/2 -left-1/2 w-full h-full bg-gradient-to-br from-primary/20 to-transparent rounded-full blur-3xl animate-float"></div>
        <div className="absolute -bottom-1/2 -right-1/2 w-full h-full bg-gradient-to-tl from-secondary/20 to-transparent rounded-full blur-3xl animate-float" style={{ animationDelay: "3s" }}></div>
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-accent/15 rounded-full blur-3xl animate-pulse-glow"></div>
      </div>

      {/* Floating Particles */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(30)].map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full bg-primary/20"
            style={{
              width: `${Math.random() * 6 + 2}px`,
              height: `${Math.random() * 6 + 2}px`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animation: `float ${5 + Math.random() * 10}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 5}s`,
            }}
          ></div>
        ))}
      </div>

      {/* Grid Pattern */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(147,51,234,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(147,51,234,0.03)_1px,transparent_1px)] bg-[size:50px_50px] [mask-image:radial-gradient(ellipse_80%_50%_at_50%_50%,black,transparent)]"></div>

      <div className="container mx-auto px-4 py-20 relative z-10">
        <div className="max-w-4xl mx-auto text-center space-y-8 animate-fade-in">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-4 animate-scale-up">
            <Sparkles className="w-4 h-4 text-primary animate-pulse" />
            <span className="text-sm font-semibold text-foreground">Prime Digital - Your Growth Partner</span>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-bold leading-tight animate-fade-in text-foreground">
            Transform Your Business with{" "}
            <br />
            <span className="inline-flex items-center gap-3 justify-center min-h-[80px] md:min-h-[100px]">
              <span className="text-primary font-extrabold">{typedText}</span>
              <span className="inline-block w-1 h-12 md:h-16 bg-primary animate-pulse"></span>
            </span>
          </h1>
          
          <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl mx-auto animate-fade-in leading-relaxed" style={{ animationDelay: "0.2s" }}>
            Led by <span className="text-primary font-semibold">Bilal</span> and our expert team, we create powerful advertising campaigns that drive results and maximize your ROI.
          </p>

          {/* Feature highlights */}
          <div className="flex flex-wrap justify-center gap-4 pt-2 animate-fade-in" style={{ animationDelay: "0.3s" }}>
            <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-card/50 backdrop-blur-sm border border-primary/10 hover:border-primary/30 transition-all duration-300 hover:scale-105">
              <TrendingUp className="w-4 h-4 text-primary" />
              <span className="text-sm text-foreground">Proven Results</span>
            </div>
            <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-card/50 backdrop-blur-sm border border-primary/10 hover:border-primary/30 transition-all duration-300 hover:scale-105">
              <Target className="w-4 h-4 text-primary" />
              <span className="text-sm text-foreground">Targeted Campaigns</span>
            </div>
            <div className="flex items-center gap-2 px-4 py-2 rounded-lg bg-card/50 backdrop-blur-sm border border-primary/10 hover:border-primary/30 transition-all duration-300 hover:scale-105">
              <Zap className="w-4 h-4 text-primary" />
              <span className="text-sm text-foreground">Fast Delivery</span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center pt-4 animate-fade-in" style={{ animationDelay: "0.4s" }}>
            <Button 
              onClick={scrollToContact}
              size="lg" 
              className="bg-primary hover:bg-primary/90 text-lg px-8 glow-effect group"
            >
              Start Your Journey
              <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Button>
            <Button 
              variant="outline" 
              size="lg" 
              className="text-lg px-8 border-primary/50 hover:bg-primary/10"
              onClick={() => {
                const element = document.getElementById("services");
                if (element) element.scrollIntoView({ behavior: "smooth" });
              }}
            >
              Explore Services
            </Button>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 pt-12 max-w-3xl mx-auto animate-fade-in" style={{ animationDelay: "0.6s" }}>
            {[
              { number: "500+", label: "Happy Clients" },
              { number: "98%", label: "Success Rate" },
              { number: "50+", label: "Team Members" },
              { number: "24/7", label: "Support" }
            ].map((stat, index) => (
              <div key={index} className="space-y-2 hover:scale-110 transition-transform duration-300">
                <div className="text-3xl md:text-4xl font-bold text-gradient animate-bounce-slow">{stat.number}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;

import { Card } from "@/components/ui/card";
import { Star } from "lucide-react";

const testimonials = [
  {
    name: "Sarah Johnson",
    position: "CEO, TechStart",
    content: "DigiMarketo transformed our online presence completely. Their strategic approach and dedication to results are unmatched. We saw a 300% increase in qualified leads within 3 months!",
    rating: 5
  },
  {
    name: "Michael Chen",
    position: "Marketing Director, GrowthCo",
    content: "Working with this team has been a game-changer. Their expertise in SEO and PPC helped us dominate our market. Highly recommended for anyone serious about digital marketing.",
    rating: 5
  },
  {
    name: "Emily Rodriguez",
    position: "Founder, StyleHub",
    content: "The best investment we made for our business. Their social media strategies helped us build a community of loyal customers. The ROI speaks for itself - absolutely phenomenal!",
    rating: 5
  }
];

const Testimonials = () => {
  return (
    <section className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-4xl md:text-5xl font-bold">
            Client <span className="text-gradient">Testimonials</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Don't just take our word for it - hear what our clients have to say
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card
              key={index}
              className="card-gradient p-8 border-primary/20 hover:border-primary/50 transition-all duration-300 hover:scale-105 hover:-translate-y-2 animate-fade-in"
              style={{ animationDelay: `${index * 0.2}s` }}
            >
              <div className="flex gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-primary text-primary" />
                ))}
              </div>
              <p className="text-foreground mb-6 italic">
                "{testimonial.content}"
              </p>
              <div className="border-t border-primary/20 pt-4">
                <div className="font-semibold text-foreground">{testimonial.name}</div>
                <div className="text-sm text-muted-foreground">{testimonial.position}</div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;

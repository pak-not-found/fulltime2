import { Linkedin, Mail, Award, Star, Phone } from "lucide-react";

const Team = () => {
  const teamMembers = [
    {
      name: "Mr. Bilal",
      role: "Founder & CEO",
      description: "Leading digital marketing strategies with 8+ years of experience in transforming businesses",
      image: "https://api.dicebear.com/7.x/avataaars/svg?seed=Bilal",
      linkedin: "#",
      email: "bilal786khan78dgf@gmail.com",
      phone: "03266102487",
      isOwner: true,
      specialization: "Strategic Planning",
    },
    {
      name: "Ahmed Khan",
      role: "Facebook Ads Specialist",
      description: "Expert in creating high-converting Facebook ad campaigns with proven track record",
      image: "https://api.dicebear.com/7.x/avataaars/svg?seed=Ahmed",
      linkedin: "#",
      email: "ahmed@example.com",
      isOwner: false,
      specialization: "Social Media Ads",
    },
    {
      name: "Sarah Ali",
      role: "YouTube Marketing Manager",
      description: "Specialist in YouTube growth and video marketing strategies that drive engagement",
      image: "https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah",
      linkedin: "#",
      email: "sarah@example.com",
      isOwner: false,
      specialization: "Video Marketing",
    },
    {
      name: "Hassan Raza",
      role: "Google Ads Expert",
      description: "Certified Google Ads professional with proven ROI results and campaign optimization",
      image: "https://api.dicebear.com/7.x/avataaars/svg?seed=Hassan",
      linkedin: "#",
      email: "hassan@example.com",
      isOwner: false,
      specialization: "Search Ads",
    },
    {
      name: "Fatima Noor",
      role: "Content Marketing Lead",
      description: "Creative content strategist and SEO optimization expert driving organic growth",
      image: "https://api.dicebear.com/7.x/avataaars/svg?seed=Fatima",
      linkedin: "#",
      email: "fatima@example.com",
      isOwner: false,
      specialization: "Content & SEO",
    },
  ];

  return (
    <section id="team" className="py-20 bg-gradient-to-b from-background via-background/95 to-background/50 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-20 left-10 w-72 h-72 bg-primary/5 rounded-full blur-3xl animate-pulse-glow" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-primary/5 rounded-full blur-3xl animate-pulse-glow" style={{ animationDelay: "1s" }} />
      </div>

      <div className="container mx-auto px-4">
        <div className="text-center mb-16 animate-fade-in">
          <div className="inline-flex items-center gap-2 bg-primary/10 px-4 py-2 rounded-full mb-4">
            <Award className="w-5 h-5 text-primary" />
            <span className="text-sm font-semibold text-primary">Expert Team</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold mb-4 text-gradient">
            Meet Our Specialists
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            A passionate group of digital marketing professionals dedicated to your success with proven expertise
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {teamMembers.map((member, index) => (
            <div
              key={member.name}
              className={`group relative card-gradient rounded-2xl p-8 hover:shadow-2xl transition-all duration-500 hover:-translate-y-3 animate-fade-in border border-border/50 hover:border-primary/30 ${
                member.isOwner ? "lg:col-span-3 lg:max-w-3xl lg:mx-auto border-2 border-primary/30 shadow-xl" : ""
              }`}
              style={{ animationDelay: `${index * 100}ms` }}
            >
              {/* Owner Badge */}
              {member.isOwner && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-gradient-to-r from-primary via-primary to-primary/80 text-primary-foreground px-6 py-2 rounded-full text-sm font-bold shadow-lg flex items-center gap-2 glow-effect">
                  <Star className="w-4 h-4 fill-current" />
                  Founder & Owner
                  <Star className="w-4 h-4 fill-current" />
                </div>
              )}
              
              {/* Specialization Badge */}
              <div className="absolute top-4 right-4 bg-primary/10 px-3 py-1 rounded-full text-xs font-semibold text-primary">
                {member.specialization}
              </div>
              
              <div className={`flex ${member.isOwner ? "flex-col md:flex-row" : "flex-col"} items-center gap-6`}>
                {/* Avatar with enhanced styling */}
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-primary/5 rounded-full blur-lg group-hover:blur-xl transition-all duration-300" />
                  <div className="relative w-32 h-32 rounded-full overflow-hidden ring-4 ring-primary/30 group-hover:ring-primary/50 group-hover:ring-offset-4 ring-offset-background transition-all duration-300 shadow-lg">
                    <img
                      src={member.image}
                      alt={member.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                  </div>
                  {member.isOwner && (
                    <div className="absolute -bottom-2 -right-2 w-12 h-12 bg-gradient-to-br from-primary to-primary/80 rounded-full flex items-center justify-center text-2xl shadow-xl animate-pulse-glow">
                      👑
                    </div>
                  )}
                </div>

                {/* Content */}
                <div className={`flex-1 ${member.isOwner ? "md:text-left" : "text-center"}`}>
                  <h3 className="text-2xl font-bold mb-2 group-hover:text-primary transition-colors">{member.name}</h3>
                  <p className="text-primary font-semibold mb-3 text-sm uppercase tracking-wide">{member.role}</p>
                  <p className="text-muted-foreground mb-4 leading-relaxed">{member.description}</p>
                  
                  {/* Social Links */}
                  <div className={`flex gap-3 ${member.isOwner ? "md:justify-start justify-center" : "justify-center"}`}>
                    <a
                      href={member.linkedin}
                      className="w-11 h-11 rounded-full bg-primary/10 hover:bg-primary flex items-center justify-center transition-all duration-300 group/icon hover:scale-110 hover:shadow-lg"
                      aria-label={`${member.name}'s LinkedIn`}
                    >
                      <Linkedin className="w-5 h-5 text-primary group-hover/icon:text-primary-foreground transition-colors" />
                    </a>
                    <a
                      href={`mailto:${member.email}`}
                      className="w-11 h-11 rounded-full bg-primary/10 hover:bg-primary flex items-center justify-center transition-all duration-300 group/icon hover:scale-110 hover:shadow-lg"
                      aria-label={`Email ${member.name}`}
                    >
                      <Mail className="w-5 h-5 text-primary group-hover/icon:text-primary-foreground transition-colors" />
                    </a>
                    {member.phone && (
                      <a
                        href={`tel:${member.phone}`}
                        className="w-11 h-11 rounded-full bg-primary/10 hover:bg-primary flex items-center justify-center transition-all duration-300 group/icon hover:scale-110 hover:shadow-lg"
                        aria-label={`Call ${member.name}`}
                      >
                        <Phone className="w-5 h-5 text-primary group-hover/icon:text-primary-foreground transition-colors" />
                      </a>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Team;

import { Card } from "@/components/ui/card";
import { Search, Share2, BarChart, Megaphone, Mail, Smartphone } from "lucide-react";

const services = [
  {
    icon: Search,
    title: "SEO Optimization",
    description: "Boost your search rankings and drive organic traffic with our proven SEO strategies."
  },
  {
    icon: Share2,
    title: "Social Media Marketing",
    description: "Build your brand presence and engage your audience across all social platforms."
  },
  {
    icon: BarChart,
    title: "Analytics & Insights",
    description: "Data-driven decisions with comprehensive analytics and performance tracking."
  },
  {
    icon: Megaphone,
    title: "PPC Advertising",
    description: "Maximize ROI with targeted pay-per-click campaigns on Google and social media."
  },
  {
    icon: Mail,
    title: "Email Marketing",
    description: "Create engaging email campaigns that convert and nurture customer relationships."
  },
  {
    icon: Smartphone,
    title: "Mobile Marketing",
    description: "Reach your audience on the go with optimized mobile marketing strategies."
  }
];

const Services = () => {
  return (
    <section id="services" className="py-20 relative">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-4xl md:text-5xl font-bold">
            Our <span className="text-gradient">Services</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Comprehensive digital marketing solutions tailored to your business needs
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <Card
              key={index}
              className="card-gradient p-8 border-primary/20 hover:border-primary/50 transition-all duration-300 hover:scale-105 hover:shadow-xl group cursor-pointer animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="w-14 h-14 rounded-lg bg-primary/20 flex items-center justify-center mb-4 group-hover:bg-primary/30 group-hover:rotate-12 transition-all duration-300 glow-effect">
                <service.icon className="w-7 h-7 text-primary group-hover:scale-110 transition-transform" />
              </div>
              <h3 className="text-2xl font-semibold mb-3 group-hover:text-primary transition-colors">
                {service.title}
              </h3>
              <p className="text-muted-foreground">
                {service.description}
              </p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;

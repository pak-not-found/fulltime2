import { Button } from "@/components/ui/button";
import { CheckCircle } from "lucide-react";

const About = () => {
  const features = [
    "Facebook Ads Management",
    "YouTube Ads Campaigns",
    "Google Ads (Search, Display & Video)",
    "Social Media Marketing",
    "Brand Strategy & Growth",
    "Result-Driven Campaigns"
  ];

  return (
    <section id="about" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6 animate-fade-in-left">
            <h2 className="text-4xl md:text-5xl font-bold">
              About <span className="text-gradient">Us</span>
            </h2>
            <p className="text-lg text-muted-foreground">
              My name is <span className="font-semibold text-foreground">Bilal</span>, and I'm a passionate Digital Marketer with years of experience in the field. I work with a dedicated and talented team of marketing experts who share the same goal — helping brands grow and succeed online.
            </p>
            <h3 className="text-2xl font-bold text-foreground pt-2">What We Do:</h3>
            <p className="text-lg text-muted-foreground">
              We specialize in creating powerful and result-driven advertising campaigns across multiple platforms.
            </p>
            
            <div className="grid sm:grid-cols-2 gap-4 pt-4">
              {features.map((feature, index) => (
                <div key={index} className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-primary flex-shrink-0" />
                  <span className="text-foreground">{feature}</span>
                </div>
              ))}
            </div>

            <div className="pt-4">
              <h3 className="text-xl font-bold text-foreground mb-2">Our Mission:</h3>
              <p className="text-lg text-muted-foreground mb-6">
                To help businesses reach their target audience, boost engagement, and maximize ROI through smart digital marketing solutions.
              </p>
              <Button 
                size="lg" 
                className="bg-primary hover:bg-primary/90 glow-effect"
                onClick={() => {
                  const element = document.getElementById("contact");
                  if (element) element.scrollIntoView({ behavior: "smooth" });
                }}
              >
                Work With Us
              </Button>
            </div>
          </div>

          <div className="relative animate-fade-in-right">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-secondary/20 rounded-3xl blur-3xl animate-pulse-glow"></div>
            <div className="relative bg-card/50 backdrop-blur-sm border border-primary/20 rounded-3xl p-8 space-y-6 hover:border-primary/40 transition-all duration-500">
              <div className="grid grid-cols-2 gap-6">
                <div className="text-center p-6 bg-primary/10 rounded-xl hover:bg-primary/20 transition-all duration-300 hover:scale-105 cursor-pointer animate-scale-up" style={{ animationDelay: "0.1s" }}>
                  <div className="text-4xl font-bold text-gradient mb-2 animate-bounce-slow">500+</div>
                  <div className="text-sm text-muted-foreground">Projects Completed</div>
                </div>
                <div className="text-center p-6 bg-secondary/10 rounded-xl hover:bg-secondary/20 transition-all duration-300 hover:scale-105 cursor-pointer animate-scale-up" style={{ animationDelay: "0.2s" }}>
                  <div className="text-4xl font-bold text-gradient mb-2 animate-bounce-slow" style={{ animationDelay: "0.5s" }}>98%</div>
                  <div className="text-sm text-muted-foreground">Client Satisfaction</div>
                </div>
                <div className="text-center p-6 bg-accent/10 rounded-xl hover:bg-accent/20 transition-all duration-300 hover:scale-105 cursor-pointer animate-scale-up" style={{ animationDelay: "0.3s" }}>
                  <div className="text-4xl font-bold text-gradient mb-2 animate-bounce-slow" style={{ animationDelay: "1s" }}>50+</div>
                  <div className="text-sm text-muted-foreground">Expert Team</div>
                </div>
                <div className="text-center p-6 bg-primary/10 rounded-xl hover:bg-primary/20 transition-all duration-300 hover:scale-105 cursor-pointer animate-scale-up" style={{ animationDelay: "0.4s" }}>
                  <div className="text-4xl font-bold text-gradient mb-2 animate-bounce-slow" style={{ animationDelay: "1.5s" }}>10+</div>
                  <div className="text-sm text-muted-foreground">Years Experience</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;

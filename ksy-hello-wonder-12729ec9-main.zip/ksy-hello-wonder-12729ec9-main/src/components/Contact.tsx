import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Mail, Phone, MapPin, MessageCircle } from "lucide-react";
import { toast } from "sonner";

const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: ""
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success("Message sent successfully! We'll get back to you soon.");
    setFormData({ name: "", email: "", message: "" });
  };

  return (
    <section id="contact" className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-4xl md:text-5xl font-bold">
            Get In <span className="text-gradient">Touch</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Let's take your brand to the next level.
          </p>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            📩 Contact us today to discuss your project and start growing your online presence.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
          <div className="space-y-8 animate-fade-in-left">
            <Card className="card-gradient p-6 border-primary/20 hover:border-primary/40 hover:scale-105 transition-all duration-300">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-lg bg-primary/20 flex items-center justify-center flex-shrink-0 group-hover:rotate-12 transition-transform animate-bounce-slow">
                  <Mail className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg mb-1">Email Us</h3>
                  <p className="text-muted-foreground">info@digimarketo.com</p>
                  <p className="text-muted-foreground">support@digimarketo.com</p>
                </div>
              </div>
            </Card>

            <Card className="card-gradient p-6 border-primary/20 hover:border-primary/40 hover:scale-105 transition-all duration-300">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-lg bg-primary/20 flex items-center justify-center flex-shrink-0 group-hover:rotate-12 transition-transform animate-bounce-slow" style={{ animationDelay: "0.5s" }}>
                  <Phone className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg mb-1">Call Us</h3>
                  <p className="text-muted-foreground">+1 (555) 123-4567</p>
                  <p className="text-muted-foreground">+1 (555) 987-6543</p>
                </div>
              </div>
            </Card>

            <Card className="card-gradient p-6 border-primary/20 hover:border-primary/40 hover:scale-105 transition-all duration-300">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-lg bg-primary/20 flex items-center justify-center flex-shrink-0 group-hover:rotate-12 transition-transform animate-bounce-slow" style={{ animationDelay: "1s" }}>
                  <MapPin className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg mb-1">Visit Us</h3>
                  <p className="text-muted-foreground">123 Digital Street</p>
                  <p className="text-muted-foreground">Marketing City, MC 12345</p>
                </div>
              </div>
            </Card>
          </div>

          <Card className="card-gradient p-8 border-primary/20 hover:border-primary/40 transition-all duration-500 animate-fade-in-right">
            <div className="space-y-6">
              <div className="text-center space-y-4">
                <div className="w-24 h-24 mx-auto bg-gradient-to-br from-[#25D366] to-[#128C7E] rounded-full flex items-center justify-center animate-scale-up">
                  <MessageCircle className="w-12 h-12 text-white" strokeWidth={2} />
                </div>
                <h3 className="text-2xl font-bold text-foreground">Chat on WhatsApp</h3>
                <p className="text-muted-foreground">
                  Click below to start a conversation with us on WhatsApp. We're here to help!
                </p>
              </div>

              <Button
                size="lg"
                className="w-full bg-[#25D366] hover:bg-[#128C7E] text-white text-lg py-6 glow-effect group"
                onClick={() => {
                  // Replace with your WhatsApp number (with country code, no + or spaces)
                  const phoneNumber = "923001234567"; // Example: Pakistan number
                  const message = encodeURIComponent("Hi! I'm interested in your digital marketing services.");
                  window.open(`https://wa.me/${phoneNumber}?text=${message}`, '_blank');
                }}
              >
                <MessageCircle className="mr-2 w-6 h-6 group-hover:scale-110 transition-transform" />
                Open WhatsApp
              </Button>

              <div className="text-center pt-4">
                <p className="text-sm text-muted-foreground">Or use the form below</p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4 pt-2">
                <Input
                  placeholder="Your Name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                  className="bg-background/50 border-primary/20 focus:border-primary"
                />
                <Input
                  type="email"
                  placeholder="Your Email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  required
                  className="bg-background/50 border-primary/20 focus:border-primary"
                />
                <Textarea
                  placeholder="Your Message"
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  required
                  rows={4}
                  className="bg-background/50 border-primary/20 focus:border-primary"
                />
                <Button type="submit" size="lg" className="w-full bg-primary hover:bg-primary/90">
                  Send Message
                </Button>
              </form>
            </div>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default Contact;

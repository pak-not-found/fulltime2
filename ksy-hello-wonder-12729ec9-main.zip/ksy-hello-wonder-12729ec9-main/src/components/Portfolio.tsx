import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp } from "lucide-react";

const projects = [
  {
    title: "E-commerce Brand",
    category: "SEO & PPC",
    result: "300% ROI Increase",
    description: "Transformed a struggling e-commerce store into a market leader through strategic SEO and targeted PPC campaigns."
  },
  {
    title: "SaaS Startup",
    category: "Social Media",
    result: "50K New Users",
    description: "Built a strong social media presence resulting in massive user acquisition and brand recognition."
  },
  {
    title: "Local Business",
    category: "Local SEO",
    result: "200% Traffic Growth",
    description: "Dominated local search results and drove foot traffic through comprehensive local SEO strategies."
  },
  {
    title: "Tech Company",
    category: "Content Marketing",
    result: "5M Page Views",
    description: "Created a content strategy that established thought leadership and generated millions of page views."
  },
  {
    title: "Fashion Brand",
    category: "Influencer Marketing",
    result: "10X Engagement",
    description: "Leveraged influencer partnerships to create viral campaigns and drive unprecedented engagement."
  },
  {
    title: "Healthcare Provider",
    category: "Email Marketing",
    result: "45% Conversion Rate",
    description: "Developed personalized email campaigns that significantly improved patient engagement and conversions."
  }
];

const Portfolio = () => {
  return (
    <section id="portfolio" className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-4xl md:text-5xl font-bold">
            Success <span className="text-gradient">Stories</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Real results from real businesses. See how we've helped our clients achieve their goals.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <Card
              key={index}
              className="card-gradient p-6 border-primary/20 hover:border-primary/50 transition-all duration-300 hover:scale-105 hover:rotate-1 group cursor-pointer animate-fade-in"
              style={{ animationDelay: `${index * 0.15}s` }}
            >
              <Badge className="mb-4 bg-primary/20 text-primary hover:bg-primary/30">
                {project.category}
              </Badge>
              <h3 className="text-2xl font-semibold mb-2 group-hover:text-primary transition-colors">
                {project.title}
              </h3>
              <div className="flex items-center gap-2 mb-4">
                <TrendingUp className="w-5 h-5 text-secondary" />
                <span className="text-secondary font-semibold">{project.result}</span>
              </div>
              <p className="text-muted-foreground">
                {project.description}
              </p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Portfolio;
